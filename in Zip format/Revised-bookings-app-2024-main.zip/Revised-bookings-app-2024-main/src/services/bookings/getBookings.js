import bookings from '../../data/bookings.json' assert { type: "json" };

const getBookings = () => {
    return bookings;
}

export default getBookings;