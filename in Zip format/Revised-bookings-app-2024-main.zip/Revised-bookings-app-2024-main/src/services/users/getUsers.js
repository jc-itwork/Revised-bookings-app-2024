import users from '../../data/users.json' assert { type: "json" };

const getUsers = () => {
  return users;
}

export default getUsers;