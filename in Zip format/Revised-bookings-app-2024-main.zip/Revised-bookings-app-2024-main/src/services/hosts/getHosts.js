import hosts from '../../data/hosts.json' assert { type: "json" };

const getHosts = () => {
  return hosts;
}

export default getHosts;