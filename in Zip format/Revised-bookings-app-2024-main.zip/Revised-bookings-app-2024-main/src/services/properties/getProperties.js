import properties from '../../data/properties.json' assert { type: "json" };

const getProperties = () => {
  return properties;
}

export default getProperties;