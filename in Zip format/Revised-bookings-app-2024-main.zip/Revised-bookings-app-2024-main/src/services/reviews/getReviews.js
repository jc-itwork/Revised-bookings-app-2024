import reviews from '../../data/reviews.json' assert { type: "json" };

const getReviews = () => {
  return reviews;
}

export default getReviews;