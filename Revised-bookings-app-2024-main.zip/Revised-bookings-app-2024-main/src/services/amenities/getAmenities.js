import amenities from '../../data/amenities.json' assert { type: "json" };

const getAmenities = () => {
  return amenities;
}

export default getAmenities;